package com.example.espoverlay;

public class PlayerData {
    public float x1, y1, x2, y2;
    public int team;
    public float health;
    public float distance;

    public PlayerData(float x1, float y1, float x2, float y2, int team, float health, float distance) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.team = team;
        this.health = health;
        this.distance = distance;
    }
}