package com.example.espoverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceView;

import java.util.List;

public class ESPView extends SurfaceView {
    private List<PlayerData> players;
    private Paint paint;
    private Paint textPaint;

    public ESPView(Context context) {
        super(context);
        setZOrderOnTop(true);
        getHolder().setFormat(android.graphics.PixelFormat.TRANSLUCENT);

        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4);
        paint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(24);
        textPaint.setAntiAlias(true);
    }

    public void setPlayers(List<PlayerData> players) {
        this.players = players;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (players == null) return;

        for (PlayerData p : players) {
            canvas.drawRect(p.x1, p.y1, p.x2, p.y2, paint);
            canvas.drawText("HP: " + (int)p.health, p.x1, p.y1 - 10, textPaint);
            canvas.drawText((int)p.distance + "m", p.x1, p.y2 + 30, textPaint);
        }
    }
}
